<template>
    <div>
        <div class="grid mt-10   sm:grid-cols-1 lg:grid-cols-3  p-20  bg-white w-full">
            <div>
                <div class="font-bold">Food Recipe</div>
                <div> We provide,</div>
                <div>You choose where to go</div>
            </div>
            <div>
                <div class="font-bold">Information</div>
                <div>About us</div>
                <div>Terms and conditions</div>
            </div>
            <div clasds="">
                <div class="font-bold"> Get in touch</div>
                <div>0962247109</div>
                <div>0946900926</div>
                <div>betekbebe@gmail.com</div>
            </div>
        </div>
        <div class="text-center font-bold bg-white w-full pb-3">All right resereved</div>
    </div>
</template>
<script setup lang="ts">

</script>
<style>
</style>
